package assignment2;

public class InsuranceException extends Exception {
    public InsuranceException(String message) {
        super(message);
    }
}
